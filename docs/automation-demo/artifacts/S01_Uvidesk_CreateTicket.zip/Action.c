Action()
{

	lr_start_transaction("010_load_page");

	//web_set_sockets_option("SSL_VERSION", "AUTO");


	web_url("login", 
		"URL=http://main.norhome.casa:60006/en/customer/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bundles/uvdeskcoreframework/images/uvdesk-kb-sprite.svg", "Referer=http://main.norhome.casa:60006/bundles/uvdesksupportcenter/css/knowledgebase.css", ENDITEM, 
		"Url=/bundles/uvdeskcoreframework/images/icon-search-kb.svg", "Referer=http://main.norhome.casa:60006/bundles/uvdesksupportcenter/css/knowledgebase.css", ENDITEM, 
		"Url=/bundles/uvdeskcoreframework/images/arrow-down.svg", "Referer=http://main.norhome.casa:60006/bundles/uvdesksupportcenter/css/knowledgebase.css", ENDITEM, 
		"Url=/bundles/uvdeskcoreframework/images/icon-attachment.svg", "Referer=http://main.norhome.casa:60006/bundles/uvdesksupportcenter/css/knowledgebase.css", ENDITEM, 
		"Url=/bundles/uvdeskcoreframework/images/uvdesk-sprite.svg", "Referer=http://main.norhome.casa:60006/bundles/uvdesksupportcenter/css/knowledgebase.css", ENDITEM, 
		LAST);

	/*
	web_url("1aa0d8", 
		"URL=http://main.norhome.casa:60006/_wdt/1aa0d8", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/login", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTE4LjAuNTk5My4xMTcSIAm9KCcJk-ZaTBIFDfJGoocSBQ11aY54IfXwdwTbYXiU?alt=proto", "Referer=", ENDITEM, 
		LAST);
	*/
	

	lr_end_transaction("010_load_page",LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("020_click_on_signin");

	web_submit_data("login_2", 
		"Action=http://main.norhome.casa:60006/en/customer/login", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/login", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=_username", "Value={p_user}", ENDITEM, 
		"Name=_password", "Value={p_pass}", ENDITEM, 
		LAST);

	/*
	web_url("44fed4", 
		"URL=http://main.norhome.casa:60006/_wdt/44fed4", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);
	*/
	
	web_url("xhr", 
		"URL=http://main.norhome.casa:60006/en/customer/tickets/xhr", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("020_click_on_signin",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("030_clickon_newticket_link");

	web_url("create-ticket", 
		"URL=http://main.norhome.casa:60006/en/customer/create-ticket/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	/*
	web_url("7479e6", 
		"URL=http://main.norhome.casa:60006/_wdt/7479e6", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/create-ticket/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);
	*/
	
	lr_end_transaction("030_clickon_newticket_link",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("040_clickon_create_ticket");

	web_submit_data("create-ticket_2", 
		"Action=http://main.norhome.casa:60006/en/customer/create-ticket/", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/create-ticket/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=type", "Value=1", ENDITEM, 
		"Name=subject", "Value=my_ticket", ENDITEM, 
		"Name=reply", "Value=This is the message of the ticket", ENDITEM, 
		LAST);

	/*
	web_url("fb4838", 
		"URL=http://main.norhome.casa:60006/_wdt/fb4838", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);
	*/	

	web_url("xhr_2", 
		"URL=http://main.norhome.casa:60006/en/customer/tickets/xhr", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("040_clickon_create_ticket",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("999_logoff");

	web_url("logout", 
		"URL=http://main.norhome.casa:60006/en/customer/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/tickets", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	/*
	web_url("b9ac3e", 
		"URL=http://main.norhome.casa:60006/_wdt/b9ac3e", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://main.norhome.casa:60006/en/customer/login", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);
		*/

	lr_end_transaction("999_logoff",LR_AUTO);

	return 0;
}